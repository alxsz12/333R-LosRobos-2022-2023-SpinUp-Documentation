#include "main.h"


void Flywheel::AShoot(int vtemp)
{
    volt = vtemp;
    FlywheelStateMachine::setState(FW_STATES::Auton);
    while(def::d_discs.get() <= 90 || def::d_discs.get() == 0){
        if(def::mtr_fw.getActualVelocity() >= 180){
            IntakeStateMachine::setState(INTAKE_STATES::in);
        }
    }
    pros::delay(500);
    FlywheelStateMachine::setState(FW_STATES::off);
    pros::delay(1000);
    IntakeStateMachine::setState(INTAKE_STATES::off);
    def::controller.rumble("-");
}