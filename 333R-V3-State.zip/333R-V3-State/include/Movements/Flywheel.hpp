#pragma once
#include "main.h"

class Flywheel
{
public:
static void AShoot(const int vtemp);
};

namespace def
{
extern Flywheel flywheel;  
}

static int volt;