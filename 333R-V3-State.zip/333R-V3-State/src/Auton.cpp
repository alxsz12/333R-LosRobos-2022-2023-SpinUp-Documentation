#include "main.h"


// ------------------------Auton.cpp-----------------------------------------//
// This file is being used to control the different robot movements during   //
// the autonomous period. We have different enumerations depending on which  //
// color side and auton is selected. This allows us to be able to use our    //
// autons more effciently so we don't have to make a bunch of different      //
// autonomous programs depending on for example the color that we were given //
// We also use this file where we upload the current selected auton from the //
// brain to be able to always have it available. Then we have the different  //
// movements that we have written down below.                                //
/*---------------------------------------------------------------------------*/

Auton::Autons Auton::auton;    // default auton is deploy, if the sd card is not installed
Auton::Sides Auton::side;      // default side is Right if the sd card is not installed
Auton::Colors Auton::color;    // default color is Red if the sd card is not installed
Auton::Colors Auton::opponent; // default color is Red if the sd card is not installed

void Auton::readSettings() // read the sd card to set the settings
{
    FILE *file;                    // cpp a file object to be used later
    if (pros::usd::is_installed()) // checks if the sd card is installed before trying to read it
    {
        file = fopen("/usd/auton_settings.txt", "r"); // open the auton settings
        if (file)                                     // check to see if the file opened correctly
        {
            int autonSideAndColor; 
            fscanf(file, "%i", &autonSideAndColor);

            auton = (Auton::Autons)(autonSideAndColor / 100);
            side = (Auton::Sides)((autonSideAndColor / 10) % 10);
            color = (Auton::Colors)(autonSideAndColor % 10);
            opponent = color == Auton::Colors::Red ? Auton::Colors::Blue : Auton::Colors::Red;

            std::cout << "autonSideAndColor in sd card is " //prints to the terminal
            << std::to_string(autonSideAndColor) << ". Auton is " // the side
            << (int)auton << ", side is " << (int)side << ", and color is " << (int)color << "." << std::endl; // color
            // and the auton selected
        }
        else
        {
            std::cout << "/usd/auton_settings.txt is null."
                      << std::endl; // if the file didn't open right, tell the terminal
        }
        fclose(file); // close the file
    }
}
void Auton::suspendAsyncTask()
{
    masync_task.suspend();
}


bool Auton::cEnable()
{
    bool cEn = false;
    switch(color)//sequence loop to run the selected color
    {
        case Colors::Red:
            cEn = true;
        break; 
        case Colors::Blue:
            cEn = false;
        break;
    }
    return cEn;  
}

void Auton::runAuton(){ // Function that controls all of the autonomous movements
    Auton::readSettings(); //Loads the autons from the SD card
    Auton::suspendAsyncTask(); //Stops the async tasks

    mstartTime = mtimer.millis(); // Timer for the auton
    waitForImu(); // Wait for calibration
    Auton::cEnable();
    //Setting the initial state and then disabiling the controls
    DrivetrainStateMachine::disableControl();
    FlywheelStateMachine::disableControl();
    IntakeStateMachine::disableControl();
    EndGameStateMachine::disableControl();
    //Sets the states to disable controller inputs
    DrivetrainStateMachine::setState(DT_STATES::busy);

    switch (auton){ //Sequence loop to contain the different autons

        case Autons::none:
            //Doing Nothing
        break;
        
        case Autons::Test:
            Drivetrain::bDist(90);
            IntakeStateMachine::RollerColor();
            Drivetrain::straightForDistance(5_in);
            Flywheel::AShoot(12000);
        break;
        }
}

void Auton::startAsyncTaskWithSettings(std::function<bool()> iasyncCondition, std::function<void()> iasyncAction)
{
    masyncCondition = iasyncCondition;
    masyncAction = iasyncAction;
    masync_task.resume();
}
void Auton::async_task_func(void *)
{
    while (true)
    {
        if (masyncCondition())
        {
            masyncAction();
            masync_task.suspend();
        }
        pros::delay(20);
    }
}
std::function<bool()> Auton::masyncCondition = []()
{ return false; };
std::function<void()> Auton::masyncAction;
pros::Task Auton::masync_task(Auton::async_task_func);

void Auton::startTaskAfterDelay(QTime idelay, std::function<void()> iaction)
{
    mdelayAction = iaction;
    mdelayTime = idelay;
    mdelay_task.resume();
}
void Auton::delay_task_func(void *)
{
    while (true)
    {
        if (mtimer.millis() - mstartTime > mdelayTime)
        {
            mdelayAction();
            mdelay_task.suspend();
        }
        pros::delay(20);
    }
}
std::function<void()> Auton::mdelayAction;
Timer Auton::mtimer = Timer();
QTime Auton::mstartTime = 0_ms;
QTime Auton::mdelayTime = 2_min;
pros::Task Auton::mdelay_task(Auton::delay_task_func);